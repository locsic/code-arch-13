-- comment
a/**/a
a/***/a
a/****/a
a/*****/a
a/******/a
a/* */a
a/* **/a
a/* ***/a
a/* ****/a
a/** */a
a/** **/a
a/** ***/a
a/** ****/a
a/*** */a
a/**** */a
a/* * */a
a/* ** */a
a/** * */a
a/** ** */a
a/*  * */a
a/*  ** */a
a/**  * */a
a/**  ** */a
a/* * ** *** **** */a
a/** * ** *** **** */a


select * from table where x=5;
update
UPDATE
UpDaTe
+-*/<>=~!@#%^&|`?$
'string'
B'1001'
'string\'escape'
/* comment */
/* comment /* nested */ */


+--*/<>=~!@#%^&|`?$ comment
+-*//*<>=~!@#%^&|`?$ comment */

'unclosed\'
'unclosed
B'bad'
B'unclosed

/* unclosed comment
