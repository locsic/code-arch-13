InfoNode Look and Feel
======================

InfoNode Look and Feel is developed by NNL Technology AB. Visit
<http://www.infonode.net> for more information and the latest version
of the library.

This distribution contains the following files:

- /lib                  : contains the library jar file
- /docs                 : contains the Javadoc documentation
- LICENSE.txt           : the license for InfoNode Look and Feel
- README                : this file
- RELEASE_NOTES_ILF.txt : the release notes for InfoNode Look and Feel
- README_ILF.txt        : the README file for InfoNode Look and Feel


Copyright (c) 2004 - 2009 NNL Technology AB, www.nnl.se
